package com.network.proxy.vpn;

public enum Protocol {
    TCP,
    UDP
}
