package com.network.proxy.vpn.socket

object Constant {
    const val MAX_RECEIVE_BUFFER_SIZE = 65535
}