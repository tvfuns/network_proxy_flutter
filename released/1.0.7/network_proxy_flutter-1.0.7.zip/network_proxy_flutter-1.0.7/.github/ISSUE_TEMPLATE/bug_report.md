---
name: Bug report
about: Create reports to help us improve
title: "[Windows、Mac、Android]xxx"
labels: bug
assignees: ''

---

**描述错误**

**To Reproduce**
重现行为的步骤: 如具体应用抓包失败，请说明软件名称以及具体操作页面

**屏幕截图*
